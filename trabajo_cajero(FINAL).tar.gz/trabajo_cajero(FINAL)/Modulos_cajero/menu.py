def menu(localtime):
        print("""
        =======================================
        =========== Menu Bancario =============
        =======================================
        =                                     =
        =   1. Crear un usuario               =  
        =   2. Consignar en la cuenta         =
        =   3. Retirar dinero                 =  
        =   4. Pagar Servicios                =
        =   5. Mostrar movimientos            =  
        =   6. Salir                          =  
        =                                     =  
        =======================================
             """)
        