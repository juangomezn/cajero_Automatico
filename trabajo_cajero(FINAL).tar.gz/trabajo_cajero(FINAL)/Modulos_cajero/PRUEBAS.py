from random import sample 
# Se importa un Método de la biblioteca random para generar listas aleatorias


lista = list(range(100)) # Se crea la lista base con números del 1 al 100


# Se crea una lista aleatoria con sample 
#(8 elementos aleatorios de la lista base)
vectorbs = sample(lista,8) 




def bubblesort(vectorbs):
    """Esta función ordenara el vector que se le pase como argumento con el Método de Bubble Sort"""
    
    # Se imprime la lista obtenida al principio (Desordenada)
    print("El vector a ordenar es:",vectorbs)
    n = len(vectorbs)# Se Establece la cantidad de elementos dentro del vector
    
    for i in range(n-1): 
    # Se le da un rango n para que complete el proceso. 
        for j in range(0, n-i-1): 
            # SE revisa la matriz de 0 hasta n-i-1
            if vectorbs[j] > vectorbs[j+1] :
                print(vectorbs)
                vectorbs[j], vectorbs[j+1] = vectorbs[j+1], vectorbs[j]
                print(vectorbs)
            # Se intercambian si el elemento encontrado es mayor 
            # Luego pasa al siguiente
    print ("El vector ordenado es: ",vectorbs)


bubblesort(vectorbs)